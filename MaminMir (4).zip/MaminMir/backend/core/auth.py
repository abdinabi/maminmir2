from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from pydantic import BaseModel
from typing import Optional
import random, string

from backend.database import SessionLocal
from backend.models.user import User
from backend.models.profile import UserProfile
from backend.core.security import create_access_token

router = APIRouter()

def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

def generate_code():
    """6-значный код верификации"""
    return "".join(random.choices(string.digits, k=6))

def send_email_code(email: str, code: str):
    """
    Отправка кода на email.
    В продакшене подключите SMTP (smtplib) или сервис (SendGrid, Mailgun).
    Сейчас просто выводим в консоль для разработки.
    """
    print(f"[EMAIL] Отправляем код {code} на {email}")
    # Пример с smtplib (раскомментируйте и настройте):
    # import smtplib
    # from email.mime.text import MIMEText
    # msg = MIMEText(f"Ваш код верификации: {code}")
    # msg["Subject"] = "Верификация МаминМир"
    # msg["From"] = "noreply@maminmir.kz"
    # msg["To"] = email
    # with smtplib.SMTP("smtp.gmail.com", 587) as s:
    #     s.starttls()
    #     s.login("your@gmail.com", "app_password")
    #     s.send_message(msg)

def send_sms_code(phone: str, code: str):
    """
    Отправка SMS.
    Подключите SMS-провайдер: Twilio, SMS.ru, SMSC.kz и др.
    """
    print(f"[SMS] Отправляем код {code} на {phone}")
    # Пример с Twilio:
    # from twilio.rest import Client
    # client = Client("ACCOUNT_SID", "AUTH_TOKEN")
    # client.messages.create(
    #     body=f"МаминМир: ваш код {code}",
    #     from_="+77000000000",
    #     to=phone
    # )

# ── СХЕМЫ ──────────────────────────────────────────────────────────

class RegisterRequest(BaseModel):
    email: str
    password: str
    phone: Optional[str] = None
    first_name: Optional[str] = None
    last_name: Optional[str] = None
    middle_name: Optional[str] = None
    birth_date: Optional[str] = None

class ProfileUpdate(BaseModel):
    first_name: Optional[str] = None
    last_name: Optional[str] = None
    middle_name: Optional[str] = None
    phone: Optional[str] = None
    birth_date: Optional[str] = None

class VerifyRequest(BaseModel):
    code: str

# ── РЕГИСТРАЦИЯ ─────────────────────────────────────────────────────

@router.post("/register")
def register(data: RegisterRequest, db: Session = Depends(get_db)):
    # Проверяем уникальность email
    if db.query(User).filter(User.email == data.email).first():
        raise HTTPException(status_code=400, detail="Email уже зарегистрирован")

    # Проверяем уникальность телефона
    if data.phone and db.query(User).filter(User.phone == data.phone).first():
        raise HTTPException(status_code=400, detail="Телефон уже зарегистрирован")

    # Создаём пользователя
    email_code = generate_code()
    phone_code = generate_code() if data.phone else None

    user = User(
        email=data.email,
        phone=data.phone,
        password=data.password,  # В продакшене: bcrypt хэш
        role="user",
        email_verified=False,
        email_verify_code=email_code,
        phone_verified=False,
        phone_verify_code=phone_code,
    )
    db.add(user)
    db.flush()

    # Создаём профиль
    profile = UserProfile(
        user_id=user.id,
        first_name=data.first_name,
        last_name=data.last_name,
        middle_name=data.middle_name,
        phone=data.phone,
        birth_date=data.birth_date,
    )
    db.add(profile)
    db.commit()

    # Отправляем коды
    send_email_code(data.email, email_code)
    if data.phone and phone_code:
        send_sms_code(data.phone, phone_code)

    return {
        "message": "Регистрация успешна. Проверьте email и телефон для верификации.",
        "user_id": user.id,
        "email_sent": True,
        "sms_sent": bool(data.phone),
    }

# ── ВЕРИФИКАЦИЯ EMAIL ────────────────────────────────────────────────

@router.post("/verify/email")
def verify_email(user_id: int, data: VerifyRequest, db: Session = Depends(get_db)):
    user = db.query(User).filter(User.id == user_id).first()
    if not user:
        raise HTTPException(status_code=404, detail="Пользователь не найден")
    if user.email_verified:
        return {"message": "Email уже подтверждён"}
    if user.email_verify_code != data.code:
        raise HTTPException(status_code=400, detail="Неверный код")
    user.email_verified = True
    user.email_verify_code = None
    db.commit()
    return {"message": "Email подтверждён"}

# ── ВЕРИФИКАЦИЯ ТЕЛЕФОНА ─────────────────────────────────────────────

@router.post("/verify/phone")
def verify_phone(user_id: int, data: VerifyRequest, db: Session = Depends(get_db)):
    user = db.query(User).filter(User.id == user_id).first()
    if not user:
        raise HTTPException(status_code=404, detail="Пользователь не найден")
    if user.phone_verified:
        return {"message": "Телефон уже подтверждён"}
    if user.phone_verify_code != data.code:
        raise HTTPException(status_code=400, detail="Неверный код")
    user.phone_verified = True
    user.phone_verify_code = None
    db.commit()
    return {"message": "Телефон подтверждён"}

# ── ПОВТОРНАЯ ОТПРАВКА КОДА ──────────────────────────────────────────

@router.post("/resend-code")
def resend_code(user_id: int, type: str, db: Session = Depends(get_db)):
    user = db.query(User).filter(User.id == user_id).first()
    if not user:
        raise HTTPException(status_code=404, detail="Пользователь не найден")
    code = generate_code()
    if type == "email":
        user.email_verify_code = code
        db.commit()
        send_email_code(user.email, code)
        return {"message": "Код отправлен на email"}
    elif type == "phone":
        if not user.phone:
            raise HTTPException(status_code=400, detail="Телефон не указан")
        user.phone_verify_code = code
        db.commit()
        send_sms_code(user.phone, code)
        return {"message": "Код отправлен по SMS"}
    raise HTTPException(status_code=400, detail="type должен быть email или phone")

# ── ВХОД ────────────────────────────────────────────────────────────

@router.post("/login")
def login(email: str, password: str, db: Session = Depends(get_db)):
    user = db.query(User).filter(User.email == email).first()
    if not user or user.password != password:
        raise HTTPException(status_code=401, detail="Неверный email или пароль")

    profile = db.query(UserProfile).filter(UserProfile.user_id == user.id).first()
    full_name = ""
    if profile:
        parts = [profile.last_name, profile.first_name, profile.middle_name]
        full_name = " ".join(p for p in parts if p)

    token = create_access_token({
        "sub": user.email,
        "role": user.role,
        "id": user.id,
        "email_verified": user.email_verified,
        "phone_verified": user.phone_verified,
        "full_name": full_name,
    })
    return {
        "access_token": token,
        "email_verified": user.email_verified,
        "phone_verified": user.phone_verified,
    }

# ── ПРОФИЛЬ ──────────────────────────────────────────────────────────

@router.get("/profile/{user_id}")
def get_profile(user_id: int, db: Session = Depends(get_db)):
    user = db.query(User).filter(User.id == user_id).first()
    if not user:
        raise HTTPException(status_code=404, detail="Не найден")
    profile = db.query(UserProfile).filter(UserProfile.user_id == user_id).first()
    return {
        "id": user.id,
        "email": user.email,
        "phone": user.phone,
        "role": user.role,
        "email_verified": user.email_verified,
        "phone_verified": user.phone_verified,
        "first_name":  profile.first_name  if profile else None,
        "last_name":   profile.last_name   if profile else None,
        "middle_name": profile.middle_name if profile else None,
        "birth_date":  profile.birth_date  if profile else None,
    }

@router.put("/profile/{user_id}")
def update_profile(user_id: int, data: ProfileUpdate, db: Session = Depends(get_db)):
    profile = db.query(UserProfile).filter(UserProfile.user_id == user_id).first()
    if not profile:
        profile = UserProfile(user_id=user_id)
        db.add(profile)
    if data.first_name  is not None: profile.first_name  = data.first_name
    if data.last_name   is not None: profile.last_name   = data.last_name
    if data.middle_name is not None: profile.middle_name = data.middle_name
    if data.birth_date  is not None: profile.birth_date  = data.birth_date
    if data.phone is not None:
        profile.phone = data.phone
        user = db.query(User).filter(User.id == user_id).first()
        if user: user.phone = data.phone
    db.commit()
    return {"message": "Профиль обновлён"}