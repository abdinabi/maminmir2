from fastapi import Header, HTTPException

def is_admin(role: str = Header(default="user")):
    if role != "admin":
        raise HTTPException(status_code=403, detail="Not admin")
