"""add new column

Revision ID: 6fa9aa483fbf
Revises: 80ac2544a11c
Create Date: 2026-04-10 11:54:49.808837

"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision: str = '6fa9aa483fbf'
down_revision: Union[str, Sequence[str], None] = '80ac2544a11c'
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    """Upgrade schema."""
    pass


def downgrade() -> None:
    """Downgrade schema."""
    pass
