from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from backend.database import SessionLocal
from backend.models.stock import Stock
from backend.models.store import Store

router = APIRouter()

def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

# ВАЖНО: GET /by-product/{id} — статичный префикс ДО любых конфликтов

@router.get("/by-product/{product_id}")
def get_stock_by_product(product_id: int, db: Session = Depends(get_db)):
    stocks = db.query(Stock).filter(Stock.product_id == product_id).all()
    result = []
    for s in stocks:
        store = db.query(Store).filter(Store.id == s.store_id).first()
        result.append({
            "id": s.id,
            "product_id": s.product_id,
            "store_id": s.store_id,
            "store_name": store.name if store else None,
            "store_address": store.address if store else None,
            "quantity": s.quantity,
        })
    return result

@router.post("/")
def set_stock(product_id: int, store_id: int, quantity: int, db: Session = Depends(get_db)):
    stock = Stock(product_id=product_id, store_id=store_id, quantity=quantity)
    db.add(stock)
    db.commit()
    db.refresh(stock)
    return stock

@router.get("/{product_id}")
def get_stock(product_id: int, db: Session = Depends(get_db)):
    stocks = db.query(Stock).filter(Stock.product_id == product_id).all()
    result = []
    for s in stocks:
        store = db.query(Store).filter(Store.id == s.store_id).first()
        result.append({
            "id": s.id,
            "product_id": s.product_id,
            "store_id": s.store_id,
            "store_name": store.name if store else None,
            "store_address": store.address if store else None,
            "quantity": s.quantity,
        })
    return result