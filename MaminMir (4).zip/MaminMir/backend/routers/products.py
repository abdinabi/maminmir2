import os, uuid, shutil
from fastapi import APIRouter, Depends, UploadFile, File
from sqlalchemy.orm import Session
from backend.database import SessionLocal
from backend.models.product import Product, Category

router = APIRouter()

UPLOAD_DIR = "frontend/uploads"
os.makedirs(UPLOAD_DIR, exist_ok=True)

def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

def product_with_category(p, db):
    result = p.__dict__.copy()
    result.pop("_sa_instance_state", None)
    if p.category_id:
        cat = db.query(Category).filter(Category.id == p.category_id).first()
        result["category_name"] = cat.name if cat else None
    else:
        result["category_name"] = None
    return result

# ── СТАТИЧНЫЕ ПУТИ ПЕРВЫМИ ──────────────────────────────

@router.get("/filter")
def filter_products(
    min_price: int = None,
    max_price: int = None,
    search: str = None,
    db: Session = Depends(get_db)
):
    query = db.query(Product)
    if min_price: query = query.filter(Product.price >= min_price)
    if max_price: query = query.filter(Product.price <= max_price)
    if search:    query = query.filter(Product.name.ilike(f"%{search}%"))
    return [product_with_category(p, db) for p in query.all()]

@router.get("/")
def get_all_products(db: Session = Depends(get_db)):
    return [product_with_category(p, db) for p in db.query(Product).all()]

@router.post("/")
def create_product(
    name: str,
    description: str = "",
    price: int = 0,
    category_id: int = None,
    db: Session = Depends(get_db)
):
    p = Product(name=name, description=description, price=price, category_id=category_id)
    db.add(p)
    db.commit()
    db.refresh(p)
    return product_with_category(p, db)

# ── ФОТО ────────────────────────────────────────────────

@router.post("/{product_id}/image")
async def upload_image(
    product_id: int,
    file: UploadFile = File(...),
    db: Session = Depends(get_db)
):
    p = db.query(Product).filter(Product.id == product_id).first()
    if not p:
        return {"error": "not found"}

    # Удаляем старое фото если есть
    if p.image_url:
        old_path = p.image_url.lstrip("/")
        if os.path.exists(old_path):
            os.remove(old_path)

    # Сохраняем новое — уникальное имя
    ext = os.path.splitext(file.filename or "img.jpg")[1].lower() or ".jpg"
    filename = f"{uuid.uuid4().hex}{ext}"
    filepath = os.path.join(UPLOAD_DIR, filename)

    with open(filepath, "wb") as f:
        shutil.copyfileobj(file.file, f)

    p.image_url = f"/uploads/{filename}"
    db.commit()
    return {"image_url": p.image_url}

@router.delete("/{product_id}/image")
def delete_image(product_id: int, db: Session = Depends(get_db)):
    p = db.query(Product).filter(Product.id == product_id).first()
    if not p:
        return {"error": "not found"}
    if p.image_url:
        old_path = p.image_url.lstrip("/")
        if os.path.exists(old_path):
            os.remove(old_path)
        p.image_url = None
        db.commit()
    return {"ok": True}

# ── ДИНАМИЧЕСКИЕ ПУТИ ПОСЛЕДНИМИ ────────────────────────

@router.get("/{product_id}")
def get_product(product_id: int, db: Session = Depends(get_db)):
    p = db.query(Product).filter(Product.id == product_id).first()
    if not p:
        return None
    return product_with_category(p, db)

@router.put("/{product_id}")
def update_product(
    product_id: int,
    name: str = None,
    description: str = None,
    price: int = None,
    category_id: int = None,
    db: Session = Depends(get_db)
):
    p = db.query(Product).filter(Product.id == product_id).first()
    if not p:
        return {"error": "not found"}
    if name is not None:        p.name = name
    if description is not None: p.description = description
    if price is not None:       p.price = price
    if category_id is not None: p.category_id = category_id
    db.commit()
    db.refresh(p)
    return product_with_category(p, db)

@router.delete("/{product_id}")
def delete_product(product_id: int, db: Session = Depends(get_db)):
    p = db.query(Product).filter(Product.id == product_id).first()
    if p:
        if p.image_url:
            old_path = p.image_url.lstrip("/")
            if os.path.exists(old_path):
                os.remove(old_path)
        db.delete(p)
        db.commit()
    return {"ok": True}