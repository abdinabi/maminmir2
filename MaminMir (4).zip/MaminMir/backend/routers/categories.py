from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from backend.database import SessionLocal
from backend.models.product import Category

router = APIRouter()

def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

@router.get("/")
def get_categories(db: Session = Depends(get_db)):
    return db.query(Category).all()

@router.post("/")
def create_category(name: str, db: Session = Depends(get_db)):
    c = Category(name=name)
    db.add(c)
    db.commit()
    db.refresh(c)
    return c

@router.delete("/{category_id}")
def delete_category(category_id: int, db: Session = Depends(get_db)):
    c = db.query(Category).filter(Category.id == category_id).first()
    if c:
        db.delete(c)
        db.commit()
    return {"ok": True}