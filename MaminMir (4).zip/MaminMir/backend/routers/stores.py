from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from typing import Optional
from backend.database import SessionLocal
from backend.models.store import Store

router = APIRouter()

def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

def short_address(address: str) -> str:
    """Обрезаем длинный Nominatim адрес до первых двух частей"""
    if not address:
        return address
    parts = [p.strip() for p in address.split(",")]
    # Берём первые 2 части — улица + город
    return ", ".join(parts[:2]) if len(parts) >= 2 else address

@router.get("/")
def get_stores(db: Session = Depends(get_db)):
    return db.query(Store).all()

@router.post("/")
def create_store(
    name: str,
    address: str,
    lat: Optional[float] = None,
    lng: Optional[float] = None,
    db: Session = Depends(get_db)
):
    s = Store(
        name=name,
        address=short_address(address),
        lat=lat,
        lng=lng
    )
    db.add(s)
    db.commit()
    db.refresh(s)
    return s

@router.delete("/{store_id}")
def delete_store(store_id: int, db: Session = Depends(get_db)):
    s = db.query(Store).filter(Store.id == store_id).first()
    if s:
        db.delete(s)
        db.commit()
    return {"ok": True}