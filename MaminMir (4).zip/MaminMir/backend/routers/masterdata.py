from fastapi import APIRouter, UploadFile, File, HTTPException
from fastapi.responses import StreamingResponse
from sqlalchemy.orm import Session
from fastapi import Depends
from backend.database import SessionLocal
from backend.models.product import Product, Category
from backend.models.stock import Stock
from backend.models.store import Store
import openpyxl
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.utils import get_column_letter
import io

router = APIRouter()

def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

# ── Стили для Excel ────────────────────────────────────────
HEADER_FILL   = PatternFill("solid", fgColor="C9956A")
HEADER_FONT   = Font(bold=True, color="FFFFFF", size=11)
HEADER_ALIGN  = Alignment(horizontal="center", vertical="center")
CELL_ALIGN    = Alignment(vertical="center")
THIN_BORDER   = Border(
    left=Side(style="thin", color="E8D9C5"),
    right=Side(style="thin", color="E8D9C5"),
    top=Side(style="thin", color="E8D9C5"),
    bottom=Side(style="thin", color="E8D9C5"),
)

def style_header(ws, headers, col_widths):
    for col, (header, width) in enumerate(zip(headers, col_widths), 1):
        cell = ws.cell(row=1, column=col, value=header)
        cell.font   = HEADER_FONT
        cell.fill   = HEADER_FILL
        cell.alignment = HEADER_ALIGN
        cell.border = THIN_BORDER
        ws.column_dimensions[get_column_letter(col)].width = width
    ws.row_dimensions[1].height = 28

def style_row(ws, row, num_cols):
    fill = PatternFill("solid", fgColor="FDF8F2") if row % 2 == 0 else PatternFill("solid", fgColor="FFFFFF")
    for col in range(1, num_cols + 1):
        cell = ws.cell(row=row, column=col)
        cell.fill      = fill
        cell.alignment = CELL_ALIGN
        cell.border    = THIN_BORDER

# ══════════════════════════════════════════════════════════
# ЭКСПОРТ
# ══════════════════════════════════════════════════════════

@router.get("/export/products")
def export_products(db: Session = Depends(get_db)):
    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = "Товары"

    headers    = ["ID", "Название", "Описание", "Цена", "Категория"]
    col_widths = [8, 35, 45, 14, 22]
    style_header(ws, headers, col_widths)

    products = db.query(Product).all()
    for i, p in enumerate(products, 2):
        cat = db.query(Category).filter(Category.id == p.category_id).first()
        ws.cell(i, 1, p.id)
        ws.cell(i, 2, p.name)
        ws.cell(i, 3, p.description or "")
        ws.cell(i, 4, p.price)
        ws.cell(i, 5, cat.name if cat else "")
        style_row(ws, i, 5)

    buf = io.BytesIO()
    wb.save(buf); buf.seek(0)
    return StreamingResponse(buf, media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                             headers={"Content-Disposition": "attachment; filename=products.xlsx"})


@router.get("/export/stocks")
def export_stocks(db: Session = Depends(get_db)):
    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = "Остатки"

    headers    = ["ID", "Товар", "Магазин", "Адрес магазина", "Количество"]
    col_widths = [8, 35, 28, 36, 16]
    style_header(ws, headers, col_widths)

    stocks = db.query(Stock).all()
    for i, s in enumerate(stocks, 2):
        product = db.query(Product).filter(Product.id == s.product_id).first()
        store   = db.query(Store).filter(Store.id == s.store_id).first()
        ws.cell(i, 1, s.id)
        ws.cell(i, 2, product.name if product else s.product_id)
        ws.cell(i, 3, store.name if store else s.store_id)
        ws.cell(i, 4, store.address if store else "")
        ws.cell(i, 5, s.quantity)
        style_row(ws, i, 5)

    buf = io.BytesIO()
    wb.save(buf); buf.seek(0)
    return StreamingResponse(buf, media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                             headers={"Content-Disposition": "attachment; filename=stocks.xlsx"})


@router.get("/export/template/products")
def template_products():
    """Шаблон для импорта товаров"""
    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = "Товары"

    headers    = ["Название", "Описание", "Цена", "Категория"]
    col_widths = [35, 45, 14, 22]
    style_header(ws, headers, col_widths)

    # Пример строки
    example = ["Пример товара", "Краткое описание", 1500, "Игрушки"]
    for col, val in enumerate(example, 1):
        cell = ws.cell(2, col, val)
        cell.fill = PatternFill("solid", fgColor="E8F5E9")
        cell.border = THIN_BORDER
        cell.alignment = CELL_ALIGN

    buf = io.BytesIO()
    wb.save(buf); buf.seek(0)
    return StreamingResponse(buf, media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                             headers={"Content-Disposition": "attachment; filename=template_products.xlsx"})


@router.get("/export/template/stocks")
def template_stocks(db: Session = Depends(get_db)):
    """Шаблон для импорта остатков"""
    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = "Остатки"

    headers    = ["Товар", "Магазин", "Количество"]
    col_widths = [35, 28, 16]
    style_header(ws, headers, col_widths)

    example = ["Название товара", "Название магазина", 10]
    for col, val in enumerate(example, 1):
        cell = ws.cell(2, col, val)
        cell.fill = PatternFill("solid", fgColor="E8F5E9")
        cell.border = THIN_BORDER
        cell.alignment = CELL_ALIGN

    # Доп. лист — справочники
    ws2 = wb.create_sheet("Товары (справочник)")
    ws2.cell(1, 1, "Название товара").font = Font(bold=True)
    products = db.query(Product).all()
    for i, p in enumerate(products, 2):
        ws2.cell(i, 1, p.name)
    ws2.column_dimensions["A"].width = 35

    ws3 = wb.create_sheet("Магазины (справочник)")
    ws3.cell(1, 1, "Название магазина").font = Font(bold=True)
    ws3.cell(1, 2, "Адрес").font = Font(bold=True)
    stores = db.query(Store).all()
    for i, s in enumerate(stores, 2):
        ws3.cell(i, 1, s.name)
        ws3.cell(i, 2, s.address)
    ws3.column_dimensions["A"].width = 28
    ws3.column_dimensions["B"].width = 36

    buf = io.BytesIO()
    wb.save(buf); buf.seek(0)
    return StreamingResponse(buf, media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                             headers={"Content-Disposition": "attachment; filename=template_stocks.xlsx"})


# ══════════════════════════════════════════════════════════
# ИМПОРТ
# ══════════════════════════════════════════════════════════

@router.post("/import/products")
async def import_products(file: UploadFile = File(...), db: Session = Depends(get_db)):
    content = await file.read()
    wb = openpyxl.load_workbook(io.BytesIO(content), data_only=True)
    ws = wb.active

    created = updated = skipped = 0
    errors = []

    for row_num, row in enumerate(ws.iter_rows(min_row=2, values_only=True), 2):
        # Поддерживаем оба формата: с ID (экспорт) и без ID (шаблон)
        if ws.max_column >= 5:
            # Формат экспорта: ID, Название, Описание, Цена, Категория
            _, name, description, price, category_name = (row + (None,) * 5)[:5]
        else:
            # Формат шаблона: Название, Описание, Цена, Категория
            name, description, price, category_name = (row + (None,) * 4)[:4]

        if not name or not price:
            skipped += 1
            continue

        try:
            price = int(float(str(price)))
        except:
            errors.append(f"Строка {row_num}: неверная цена '{price}'")
            skipped += 1
            continue

        # Найти или создать категорию
        category_id = None
        if category_name:
            cat = db.query(Category).filter(Category.name == str(category_name).strip()).first()
            if not cat:
                cat = Category(name=str(category_name).strip())
                db.add(cat); db.flush()
            category_id = cat.id

        # Найти существующий товар по названию
        product = db.query(Product).filter(Product.name == str(name).strip()).first()
        if product:
            product.description = str(description or "")
            product.price = price
            if category_id: product.category_id = category_id
            updated += 1
        else:
            db.add(Product(
                name=str(name).strip(),
                description=str(description or ""),
                price=price,
                category_id=category_id
            ))
            created += 1

    db.commit()
    return {
        "created": created,
        "updated": updated,
        "skipped": skipped,
        "errors":  errors,
        "message": f"Создано: {created}, обновлено: {updated}, пропущено: {skipped}"
    }


@router.post("/import/stocks")
async def import_stocks(file: UploadFile = File(...), db: Session = Depends(get_db)):
    content = await file.read()
    wb = openpyxl.load_workbook(io.BytesIO(content), data_only=True)
    ws = wb.active

    created = updated = skipped = 0
    errors = []

    for row_num, row in enumerate(ws.iter_rows(min_row=2, values_only=True), 2):
        # Поддерживаем оба формата
        if ws.max_column >= 5:
            # Формат экспорта: ID, Товар, Магазин, Адрес, Количество
            _, product_name, store_name, _, quantity = (row + (None,) * 5)[:5]
        else:
            # Формат шаблона: Товар, Магазин, Количество
            product_name, store_name, quantity = (row + (None,) * 3)[:3]

        if not product_name or not store_name or quantity is None:
            skipped += 1
            continue

        try:
            quantity = int(float(str(quantity)))
        except:
            errors.append(f"Строка {row_num}: неверное количество '{quantity}'")
            skipped += 1
            continue

        product = db.query(Product).filter(Product.name == str(product_name).strip()).first()
        store   = db.query(Store).filter(Store.name == str(store_name).strip()).first()

        if not product:
            errors.append(f"Строка {row_num}: товар '{product_name}' не найден")
            skipped += 1
            continue
        if not store:
            errors.append(f"Строка {row_num}: магазин '{store_name}' не найден")
            skipped += 1
            continue

        stock = db.query(Stock).filter(
            Stock.product_id == product.id,
            Stock.store_id == store.id
        ).first()

        if stock:
            stock.quantity = quantity
            updated += 1
        else:
            db.add(Stock(product_id=product.id, store_id=store.id, quantity=quantity))
            created += 1

    db.commit()
    return {
        "created": created,
        "updated": updated,
        "skipped": skipped,
        "errors":  errors,
        "message": f"Создано: {created}, обновлено: {updated}, пропущено: {skipped}"
    }