from sqlalchemy import Column, Integer, String, DateTime, ForeignKey
from sqlalchemy.orm import relationship
from datetime import datetime
from backend.database import Base

class Order(Base):
    __tablename__ = "orders"

    id         = Column(Integer, primary_key=True)
    user_id    = Column(Integer)
    status     = Column(String, default="Оформлен")
    created_at = Column(DateTime, default=datetime.utcnow)
    items      = relationship("OrderItem", back_populates="order", cascade="all, delete-orphan")

class OrderItem(Base):
    __tablename__ = "order_items"

    id         = Column(Integer, primary_key=True)
    order_id   = Column(Integer, ForeignKey("orders.id"))
    product_id = Column(Integer, ForeignKey("products.id"))
    name       = Column(String)   # сохраняем название на момент заказа
    price      = Column(Integer)  # сохраняем цену на момент заказа
    quantity   = Column(Integer)
    order      = relationship("Order", back_populates="items")