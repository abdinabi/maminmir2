from sqlalchemy import Column, Integer, String, Boolean
from backend.database import Base

class User(Base):
    __tablename__ = "users"

    id                   = Column(Integer, primary_key=True)
    email                = Column(String, unique=True)
    phone                = Column(String, nullable=True, unique=True)
    password             = Column(String)
    role                 = Column(String, default="user")

    # Верификация email
    email_verified       = Column(Boolean, default=False)
    email_verify_code    = Column(String, nullable=True)

    # Верификация телефона
    phone_verified       = Column(Boolean, default=False)
    phone_verify_code    = Column(String, nullable=True)