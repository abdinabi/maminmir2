from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from backend.database import SessionLocal
from backend.models.order import Order, OrderItem
from backend.models.cart import Cart, CartItem
from backend.models.product import Product

router = APIRouter()

def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

def order_to_dict(order):
    return {
        "id":         order.id,
        "user_id":    order.user_id,
        "status":     order.status,
        "created_at": order.created_at.strftime("%d.%m.%Y %H:%M") if order.created_at else None,
        "items": [
            {
                "product_id": item.product_id,
                "name":       item.name,
                "price":      item.price,
                "quantity":   item.quantity,
                "total":      item.price * item.quantity,
            }
            for item in order.items
        ],
        "total": sum(item.price * item.quantity for item in order.items),
    }

@router.get("/user/{user_id}")
def get_user_orders(user_id: int, db: Session = Depends(get_db)):
    orders = db.query(Order).filter(Order.user_id == user_id).order_by(Order.id.desc()).all()
    return [order_to_dict(o) for o in orders]

@router.get("/{order_id}")
def get_order(order_id: int, db: Session = Depends(get_db)):
    order = db.query(Order).filter(Order.id == order_id).first()
    if not order:
        raise HTTPException(status_code=404, detail="Заказ не найден")
    return order_to_dict(order)

@router.post("/")
def create_order(user_id: int, db: Session = Depends(get_db)):
    cart = db.query(Cart).filter(Cart.user_id == user_id).first()
    order = Order(user_id=user_id, status="Оформлен")
    db.add(order)
    db.flush()
    if cart:
        cart_items = db.query(CartItem).filter(CartItem.cart_id == cart.id).all()
        for ci in cart_items:
            product = db.query(Product).filter(Product.id == ci.product_id).first()
            if product:
                db.add(OrderItem(
                    order_id=order.id,
                    product_id=ci.product_id,
                    name=product.name,
                    price=product.price,
                    quantity=ci.quantity,
                ))
        db.query(CartItem).filter(CartItem.cart_id == cart.id).delete()
        db.delete(cart)
    db.commit()
    db.refresh(order)
    return order_to_dict(order)