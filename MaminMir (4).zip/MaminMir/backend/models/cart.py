from sqlalchemy import Column, Integer
from backend.database import Base

class Cart(Base):
    __tablename__ = "cart"

    id = Column(Integer, primary_key=True)
    user_id = Column(Integer)


class CartItem(Base):
    __tablename__ = "cart_items"

    id = Column(Integer, primary_key=True)
    cart_id = Column(Integer)
    product_id = Column(Integer)
    quantity = Column(Integer)
