from sqlalchemy import Column, Integer, String, Float
from backend.database import Base

class Store(Base):
    __tablename__ = "stores"

    id      = Column(Integer, primary_key=True)
    name    = Column(String)
    address = Column(String)
    lat     = Column(Float, nullable=True)
    lng     = Column(Float, nullable=True)