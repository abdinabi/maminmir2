from sqlalchemy import Column, Integer, String, Date, ForeignKey
from sqlalchemy.orm import relationship
from backend.database import Base

class UserProfile(Base):
    __tablename__ = "user_profiles"

    id           = Column(Integer, primary_key=True)
    user_id      = Column(Integer, ForeignKey("users.id"), unique=True)
    first_name   = Column(String, nullable=True)   # Имя
    last_name    = Column(String, nullable=True)   # Фамилия
    middle_name  = Column(String, nullable=True)   # Отчество
    phone        = Column(String, nullable=True)   # Телефон
    birth_date   = Column(String, nullable=True)   # Дата рождения (строка YYYY-MM-DD)