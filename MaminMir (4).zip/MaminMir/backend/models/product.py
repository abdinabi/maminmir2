from sqlalchemy import Column, Integer, String, ForeignKey
from backend.database import Base

class Category(Base):
    __tablename__ = "categories"
    id   = Column(Integer, primary_key=True)
    name = Column(String)

class Product(Base):
    __tablename__ = "products"

    id          = Column(Integer, primary_key=True)
    name        = Column(String)
    description = Column(String)
    price       = Column(Integer)
    category_id = Column(Integer, ForeignKey("categories.id"))
    image_url   = Column(String, nullable=True)  # путь к фото