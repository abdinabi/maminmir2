// Если открыто через сервер — используем тот же хост, иначе localhost:8000
const BASE = (location.hostname === "127.0.0.1" || location.hostname === "localhost") && location.port
  ? `${location.protocol}//${location.hostname}:${location.port}`
  : "http://localhost:8000";

let currentUser = null, cart = [], authMode = "login", searchTimer = null, allProducts = [];
let adminProductsList = [], adminStoresList = [], adminCategoriesList = [];

// ── API ────────────────────────────────────────────────────────────────────────
function getToken() { return localStorage.getItem("token"); }

async function api(path, options = {}) {
  const token = getToken();
  const headers = {
    "Content-Type": "application/json",
    ...(token ? { Authorization: `Bearer ${token}` } : {}),
    ...options.headers
  };
  const res = await fetch(BASE + path, { ...options, headers });
  if (res.status === 401) { logout(); return; }
  if (!res.ok) {
    const err = await res.json().catch(() => ({}));
    throw new Error(err.detail || "Ошибка запроса");
  }
  return res.json();
}

function fmt(n) { return Number(n).toLocaleString("ru-RU"); }

const EMOJI = { игрушки: "🧸", одежда: "👗", питание: "🍼", уход: "🧴", коляски: "🛒", мебель: "🪑" };
function getEmoji(name) {
  if (!name) return "🧸";
  const k = (name || "").toLowerCase();
  for (const [key, val] of Object.entries(EMOJI)) if (k.includes(key)) return val;
  return "🧸";
}

// ── AUTH ───────────────────────────────────────────────────────────────────────
function switchMode(mode) {
  authMode = mode;
  document.querySelectorAll(".auth-tab").forEach((t, i) =>
    t.classList.toggle("active", (mode === "login" && i === 0) || (mode === "register" && i === 1)));
  document.getElementById("authSub").textContent = mode === "login" ? "Войдите в аккаунт" : "Создайте аккаунт";
  document.getElementById("authBtn").textContent = mode === "login" ? "Войти" : "Зарегистрироваться";
  document.getElementById("authError").style.display = "none";
}

async function handleAuth() {
  const email = document.getElementById("authEmail").value.trim();
  const password = document.getElementById("authPassword").value;
  const btn = document.getElementById("authBtn");
  if (!email || !password) { showAuthError("Заполните все поля"); return; }
  btn.disabled = true; btn.textContent = "Подождите…";
  document.getElementById("authError").style.display = "none";
  try {
    if (authMode === "register")
      await api(`/auth/register?email=${encodeURIComponent(email)}&password=${encodeURIComponent(password)}`, { method: "POST" });
    const data = await api(`/auth/login?email=${encodeURIComponent(email)}&password=${encodeURIComponent(password)}`, { method: "POST" });
    if (data.error) throw new Error(data.error);
    localStorage.setItem("token", data.access_token);
    const payload = JSON.parse(atob(data.access_token.split(".")[1]));
    currentUser = { email: payload.sub, role: payload.role, id: payload.id || 1 };
    localStorage.setItem("user", JSON.stringify(currentUser));
    enterApp();
  } catch (e) {
    showAuthError(e.message || "Ошибка входа");
  } finally {
    btn.disabled = false;
    btn.textContent = authMode === "login" ? "Войти" : "Зарегистрироваться";
  }
}

function showAuthError(msg) {
  const el = document.getElementById("authError");
  el.textContent = msg; el.style.display = "block";
}

// ── LANDING ────────────────────────────────────────────────────────────────────
let landingMap = null, landingMarkers = {};

function showLanding() {
  const lw = document.getElementById("landingWrap");
  const aw = document.getElementById("appWrap");
  const am = document.getElementById("authModal");
  if (lw) lw.style.display = "block";
  if (aw) aw.style.display = "none";
  if (am) am.style.display = "none";
  loadLandingData();
}

function enterCatalog() {
  const lw = document.getElementById("landingWrap");
  const aw = document.getElementById("appWrap");
  if (lw) lw.style.display = "none";
  if (aw) aw.style.display = "block";
  showPage("catalog");
  if (!allProducts.length) loadProducts();
}

function smoothTo(id) {
  const el = document.getElementById(id);
  if (el) el.scrollIntoView({ behavior: "smooth" });
}

async function loadLandingData() {
  try {
    const [stores, products] = await Promise.all([
      api("/admin/stores/"),
      api("/products/filter"),
    ]);
    const sEl = document.getElementById("statStores");
    const pEl = document.getElementById("statProducts");
    if (sEl) sEl.textContent = stores.length;
    if (pEl) pEl.textContent = products.length;
    renderLandingStores(stores);
  } catch(e) {}
}

function renderLandingStores(stores) {
  const list = document.getElementById("landingStoresList");
  if (!list) return;
  if (!stores.length) {
    list.innerHTML = '<div class="state-msg" style="padding:24px"><span class="emoji">🏪</span>Магазины не добавлены</div>';
    return;
  }
  list.innerHTML = stores.map(function(s) {
    return '<div class="store-item" id="lstore-' + s.id + '" onclick="focusStore(' + s.id + ')">' +
      '<h4>' + s.name + '</h4><p>📍 ' + s.address + '</p></div>';
  }).join("");
  setTimeout(function() {
    const mapEl = document.getElementById("landingMap");
    if (!mapEl || typeof L === "undefined") return;
    if (landingMap) { landingMap.remove(); landingMap = null; }
    landingMap = L.map("landingMap").setView([43.238, 76.945], 12);
    L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", { attribution: "© OpenStreetMap" }).addTo(landingMap);
    landingMarkers = {};
    stores.forEach(function(s) {
      if (s.lat && s.lng) {
        var m = L.marker([s.lat, s.lng]).addTo(landingMap).bindPopup("<b>" + s.name + "</b><br>" + s.address);
        landingMarkers[s.id] = m;
      }
    });
    var withCoords = stores.filter(function(s){ return s.lat && s.lng; });
    if (withCoords.length && Object.keys(landingMarkers).length) {
      var group = L.featureGroup(Object.values(landingMarkers));
      landingMap.fitBounds(group.getBounds().pad(0.2));
    }
  }, 200);
}

function focusStore(id) {
  document.querySelectorAll(".store-item").forEach(function(el){ el.classList.remove("active"); });
  var item = document.getElementById("lstore-" + id);
  if (item) item.classList.add("active");
  var marker = landingMarkers[id];
  if (marker && landingMap) { landingMap.setView(marker.getLatLng(), 15); marker.openPopup(); }
}

// ── AUTH MODAL ─────────────────────────────────────────────────────────────────
var authRequired = false;
var pendingCheckout = false;

function openAuthModal(required) {
  authRequired = !!required;
  var modal = document.getElementById("authModal");
  if (modal) modal.style.display = "flex";
  var closeBtn = document.getElementById("authModalClose");
  if (closeBtn) closeBtn.style.display = authRequired ? "none" : "block";
  document.getElementById("authEmail").value = "";
  document.getElementById("authPassword").value = "";
  document.getElementById("authError").style.display = "none";
}

function closeAuthModal() {
  if (authRequired) return;
  var modal = document.getElementById("authModal");
  if (modal) modal.style.display = "none";
  pendingCheckout = false;
}

function enterApp() {
  var modal = document.getElementById("authModal");
  var lw    = document.getElementById("landingWrap");
  var aw    = document.getElementById("appWrap");
  var ub    = document.getElementById("userInfoBlock");
  var bl    = document.getElementById("btnLogin");
  var bo    = document.getElementById("btnOrders");
  var ba    = document.getElementById("btnAdmin");
  if (modal) modal.style.display = "none";
  if (lw)    lw.style.display    = "none";
  if (aw)    aw.style.display    = "block";
  if (ub)    ub.style.display    = "flex";
  if (bl)    bl.style.display    = "none";
  if (bo)    bo.style.display    = "inline-flex";
  document.getElementById("userEmail").textContent = currentUser.email;
  if (currentUser.role === "admin" && ba) ba.style.display = "inline-flex";
  authRequired = false;
  if (pendingCheckout) { pendingCheckout = false; placeOrder(); return; }
  loadProducts();
}

function logout() {
  localStorage.removeItem("token"); localStorage.removeItem("user");
  currentUser = null; cart = [];
  updateCartBadge();
  var ub = document.getElementById("userInfoBlock");
  var bl = document.getElementById("btnLogin");
  var bo = document.getElementById("btnOrders");
  var ba = document.getElementById("btnAdmin");
  if (ub) ub.style.display = "none";
  if (bl) bl.style.display = "inline-flex";
  if (bo) bo.style.display = "none";
  if (ba) ba.style.display = "none";
  showLanding();
}

// ── NAVIGATION ─────────────────────────────────────────────────────────────────
function showPage(name) {
  ["catalog", "product", "cart", "orders", "admin"].forEach(p => {
    document.getElementById("page" + p[0].toUpperCase() + p.slice(1)).classList.toggle("active", p === name);
  });
  ["catalog", "cart", "orders", "admin"].forEach(p => {
    const btn = document.getElementById("btn" + p[0].toUpperCase() + p.slice(1));
    if (btn) btn.classList.toggle("active", p === name);
  });
  if (name === "cart")   renderCart();
  if (name === "orders") loadOrders();
  if (name === "admin")  loadAdminData();
}

// ── SEARCH ─────────────────────────────────────────────────────────────────────
function onSearch() {
  const val = document.getElementById("searchInput").value;
  document.getElementById("searchIcon").style.display = val ? "none" : "block";
  document.getElementById("searchClear").style.display = val ? "block" : "none";
  clearTimeout(searchTimer);
  searchTimer = setTimeout(loadProducts, 350);
}

function clearSearch() {
  document.getElementById("searchInput").value = "";
  document.getElementById("searchIcon").style.display = "block";
  document.getElementById("searchClear").style.display = "none";
  loadProducts();
}

// ── PRODUCTS ───────────────────────────────────────────────────────────────────
async function loadProducts() {
  const min = document.getElementById("minPrice").value;
  const max = document.getElementById("maxPrice").value;
  const search = document.getElementById("searchInput").value.trim();
  document.getElementById("resetBtn").style.display = (min || max) ? "inline-block" : "none";
  document.getElementById("productsContainer").innerHTML = '<div class="state-msg"><span class="emoji">🌸</span>Загружаем товары…</div>';
  try {
    const params = new URLSearchParams();
    if (min) params.append("min_price", min);
    if (max) params.append("max_price", max);
    if (search) params.append("search", search);
    allProducts = await api(`/products/filter?${params}`);
    renderProducts(allProducts);
  } catch (e) {
    document.getElementById("productsContainer").innerHTML = `<div class="state-msg"><span class="emoji">⚠️</span>${e.message}</div>`;
  }
}

function resetFilter() {
  document.getElementById("minPrice").value = "";
  document.getElementById("maxPrice").value = "";
  loadProducts();
}

function renderProducts(products) {
  const el = document.getElementById("productsContainer");
  if (!products.length) { el.innerHTML = '<div class="state-msg"><span class="emoji">🔍</span>Ничего не найдено.</div>'; return; }
  el.innerHTML = `<div class="products-grid">${products.map((p, i) => `
    <div class="product-card" style="animation-delay:${i * 0.05}s" onclick="openProduct(${p.id})">
      <div class="product-img">
        ${p.image_url
          ? `<img src="${BASE}${p.image_url}" alt="${p.name}" style="width:100%;height:100%;object-fit:cover" onerror="this.parentElement.innerHTML='${getEmoji(p.category_name)}'" />`
          : `<span>${getEmoji(p.category_name)}</span>`}
      </div>
      <div class="product-body">
        ${p.category_name ? `<div class="product-category">${p.category_name}</div>` : ""}
        <div class="product-name">${p.name}</div>
        ${p.description ? `<div class="product-desc">${p.description}</div>` : ""}
        <div class="product-footer">
          <div class="product-price">${fmt(p.price)}<span>₸</span></div>
          <button class="add-btn ${isInCart(p.id) ? 'in-cart' : ''}"
            onclick="event.stopPropagation();addToCart(${JSON.stringify(p).replace(/"/g, '&quot;')})"
            title="${isInCart(p.id) ? 'В корзине' : 'Добавить'}">
            ${isInCart(p.id) ? "✓" : "+"}
          </button>
        </div>
      </div>
    </div>`).join("")}</div>`;
}

// ── PRODUCT DETAIL ─────────────────────────────────────────────────────────────
async function openProduct(id) {
  showPage("product");
  document.getElementById("productDetailContent").innerHTML = '<div class="state-msg"><span class="emoji">🌸</span>Загрузка…</div>';
  try {
    const [p, stocks] = await Promise.all([api(`/products/${id}`), api(`/stocks/${id}`)]);
    const inCart = isInCart(p.id);
    const isAdmin = currentUser && currentUser.role === "admin";
    document.getElementById("productDetailContent").innerHTML = `
      <div style="animation:fadeUp 0.4s ease">
        <div class="detail-grid">
          <div class="detail-img-wrap">
            ${p.image_url
              ? `<img id="detailImg" src="${BASE}${p.image_url}" alt="${p.name}" class="detail-img-photo" onerror="this.style.display='none';document.getElementById('detailImgEmoji').style.display='flex'" />
                 <div id="detailImgEmoji" class="detail-img" style="display:none">${getEmoji(p.category_name)}</div>`
              : `<div id="detailImgEmoji" class="detail-img">${getEmoji(p.category_name)}</div>`}
            ${isAdmin ? `
              <div class="detail-img-actions">
                <label class="img-upload-btn" title="Загрузить фото">
                  📷 ${p.image_url ? "Заменить фото" : "Добавить фото"}
                  <input type="file" accept="image/*" style="display:none" onchange="uploadProductImage(${p.id}, event)" />
                </label>
                ${p.image_url ? `<button class="img-delete-btn" onclick="deleteProductImage(${p.id})" title="Удалить фото">🗑</button>` : ""}
              </div>` : ""}
          </div>
          <div class="detail-info">
            ${p.category_name ? `<div class="detail-category">${p.category_name}</div>` : ""}
            <h1>${p.name}</h1>
            ${p.description ? `<p class="detail-desc">${p.description}</p>` : ""}
            <div class="detail-price">${fmt(p.price)}<span> ₸</span></div>
            <button class="detail-add-btn ${inCart ? 'in-cart' : ''}" id="detailAddBtn"
              onclick="addToCartFromDetail(${JSON.stringify(p).replace(/"/g, '&quot;')})">
              ${inCart ? "✓ В корзине" : "Добавить в корзину"}
            </button>
          </div>
        </div>
        <div class="stocks-section">
          <h3>Наличие в магазинах</h3>
          ${stocks.length === 0
            ? `<div class="state-msg" style="padding:20px"><span class="emoji">📦</span>Нет данных об остатках</div>`
            : stocks.map(s => `
              <div class="stock-row">
                <div class="stock-store">
                  ${s.store_name || "Магазин #" + s.store_id}
                  ${s.store_address ? `<small>${s.store_address}</small>` : ""}
                </div>
                <div class="stock-qty ${s.quantity > 5 ? 'ok' : 'low'}">${s.quantity} шт.</div>
              </div>`).join("")}
        </div>
      </div>`;
  } catch (e) {
    document.getElementById("productDetailContent").innerHTML = `<div class="state-msg"><span class="emoji">⚠️</span>${e.message}</div>`;
  }
}

async function uploadProductImage(productId, e) {
  const file = e.target.files && e.target.files[0];
  if (!file) return;
  const formData = new FormData();
  formData.append("file", file);
  const token = getToken();
  try {
    const res = await fetch(`${BASE}/products/${productId}/image`, {
      method: "POST",
      headers: token ? { Authorization: `Bearer ${token}` } : {},
      body: formData,
    });
    if (res.ok) {
      openProduct(productId); // перезагружаем страницу товара
      loadProducts();         // обновляем сетку
    } else {
      alert("Ошибка загрузки фото");
    }
  } catch { alert("Ошибка загрузки фото"); }
}

async function deleteProductImage(productId) {
  if (!confirm("Удалить фото?")) return;
  try {
    await api(`/products/${productId}/image`, { method: "DELETE" });
    openProduct(productId);
    loadProducts();
  } catch { alert("Ошибка удаления фото"); }
}

function addToCartFromDetail(product) {
  addToCart(product);
  const btn = document.getElementById("detailAddBtn");
  if (btn) { btn.textContent = "✓ В корзине"; btn.classList.add("in-cart"); }
}

// ── CART ───────────────────────────────────────────────────────────────────────
function isInCart(id) { return cart.some(i => i.product.id === id); }

function addToCart(product) {
  const existing = cart.find(i => i.product.id === product.id);
  if (existing) existing.quantity++;
  else cart.push({ product, quantity: 1 });
  updateCartBadge();
  renderProducts(allProducts);
}

function updateCartBadge() {
  const total = cart.reduce((s, i) => s + i.quantity, 0);
  const badge = document.getElementById("cartBadge");
  badge.style.display = total > 0 ? "flex" : "none";
  badge.textContent = total;
}

function changeQty(productId, delta) {
  const item = cart.find(i => i.product.id === productId);
  if (!item) return;
  item.quantity += delta;
  if (item.quantity <= 0) cart = cart.filter(i => i.product.id !== productId);
  updateCartBadge(); renderCart();
}

function removeItem(productId) {
  cart = cart.filter(i => i.product.id !== productId);
  updateCartBadge(); renderCart();
}

function renderCart() {
  const el = document.getElementById("cartContent");
  if (!cart.length) { el.innerHTML = '<div class="state-msg"><span class="emoji">🛒</span>Корзина пуста.</div>'; return; }
  const total = cart.reduce((s, i) => s + i.product.price * i.quantity, 0);
  const itemCount = cart.reduce((s, i) => s + i.quantity, 0);
  el.innerHTML = `
    <h1>Корзина</h1>
    <div class="cart-layout">
      <div class="cart-items">
        ${cart.map(i => `
          <div class="cart-item">
            <div class="cart-item-icon">${getEmoji(i.product.category_name)}</div>
            <div class="cart-item-info">
              <h3>${i.product.name}</h3>
              <p>${fmt(i.product.price)} ₸ за шт.</p>
            </div>
            <div class="qty-control">
              <button class="qty-btn" onclick="changeQty(${i.product.id},-1)">−</button>
              <span class="qty-num">${i.quantity}</span>
              <button class="qty-btn" onclick="changeQty(${i.product.id},1)">+</button>
            </div>
            <div class="cart-item-price">${fmt(i.product.price * i.quantity)} ₸</div>
            <button class="remove-btn" onclick="removeItem(${i.product.id})">✕</button>
          </div>`).join("")}
      </div>
      <div class="cart-summary">
        <h2>Итого</h2>
        <div class="summary-line"><span>Товаров</span><span>${itemCount} шт.</span></div>
        <div class="summary-line"><span>Позиций</span><span>${cart.length}</span></div>
        <div class="summary-total"><span>К оплате</span><span>${fmt(total)} ₸</span></div>
        <div class="msg-error" id="orderError" style="display:none"></div>
        <button class="checkout-btn" id="orderBtn" onclick="placeOrder()">Оформить заказ</button>
      </div>
    </div>`;
}

async function placeOrder() {
  if (!currentUser) {
    pendingCheckout = true;
    openAuthModal(true);
    return;
  }
  const btn = document.getElementById("orderBtn");
  const errEl = document.getElementById("orderError");
  btn.disabled = true; btn.textContent = "Оформляем…";
  if (errEl) errEl.style.display = "none";
  try {
    const userId = currentUser?.id || 1;
    for (const item of cart)
      await api(`/cart/add?user_id=${userId}&product_id=${item.product.id}&quantity=${item.quantity}`, { method: "POST" });
    await api(`/orders/?user_id=${userId}`, { method: "POST" });
    cart = []; updateCartBadge();
    document.getElementById("cartContent").innerHTML = `
      <div class="order-success">
        <div class="big-emoji">🎀</div>
        <h2>Заказ оформлен!</h2>
        <p>Спасибо за покупку. Мы свяжемся с вами в ближайшее время.</p>
        <button class="checkout-btn" onclick="showPage('catalog')">Вернуться в каталог</button>
      </div>`;
  } catch (e) {
    btn.disabled = false; btn.textContent = "Оформить заказ";
    if (errEl) { errEl.textContent = e.message; errEl.style.display = "block"; }
  }
}

// ── ORDERS ─────────────────────────────────────────────────────────────────────
async function loadOrders() {
  document.getElementById("ordersContent").innerHTML = '<div class="state-msg"><span class="emoji">🌸</span>Загрузка…</div>';
  try {
    const userId = currentUser?.id || 1;
    const orders = await api(`/orders/user/${userId}`);
    if (!orders.length) {
      document.getElementById("ordersContent").innerHTML = '<div class="state-msg"><span class="emoji">📋</span>Заказов пока нет.</div>';
      return;
    }
    document.getElementById("ordersContent").innerHTML = orders.map((o, i) => `
      <div class="order-card" style="animation-delay:${i * 0.06}s;cursor:pointer" onclick="openOrderModal(${o.id})">
        <div>
          <h3>Заказ #${o.id}</h3>
          <p>${o.created_at || ""} · ${o.items ? o.items.length : 0} поз. · ${fmt(o.total || 0)} ₸</p>
        </div>
        <span class="order-status">${o.status || "Оформлен"}</span>
      </div>`).join("");
  } catch (e) {
    document.getElementById("ordersContent").innerHTML = `<div class="state-msg"><span class="emoji">⚠️</span>${e.message}</div>`;
  }
}

async function openOrderModal(orderId) {
  // Создаём оверлей если его нет
  let overlay = document.getElementById("orderModalOverlay");
  if (!overlay) {
    overlay = document.createElement("div");
    overlay.id = "orderModalOverlay";
    overlay.className = "order-modal-overlay";
    overlay.onclick = e => { if (e.target === overlay) closeOrderModal(); };
    overlay.innerHTML = `
      <div class="order-modal-box">
        <div class="order-modal-header">
          <h3 id="omTitle">Заказ</h3>
          <button class="order-modal-close" onclick="closeOrderModal()">×</button>
        </div>
        <div class="order-modal-meta" id="omMeta"></div>
        <div class="order-modal-body">
          <div class="order-items-list" id="omItems"></div>
          <div class="order-total-row">
            <span>Итого</span>
            <span id="omTotal"></span>
          </div>
        </div>
      </div>`;
    document.body.appendChild(overlay);
  }

  // Показываем с загрузкой
  overlay.style.display = "flex";
  document.getElementById("omTitle").textContent = `Заказ #${orderId}`;
  document.getElementById("omMeta").innerHTML = `<span class="order-meta-tag">Загрузка…</span>`;
  document.getElementById("omItems").innerHTML = "";
  document.getElementById("omTotal").textContent = "";

  try {
    const o = await api(`/orders/${orderId}`);

    // Заголовок
    document.getElementById("omTitle").textContent = `Заказ #${o.id}`;

    // Мета-теги
    document.getElementById("omMeta").innerHTML = `
      <span class="order-meta-tag status">${o.status}</span>
      ${o.created_at ? `<span class="order-meta-tag">📅 ${o.created_at}</span>` : ""}
      <span class="order-meta-tag">📦 ${o.items.length} поз.</span>`;

    // Позиции
    document.getElementById("omItems").innerHTML = o.items.length
      ? o.items.map(item => `
          <div class="order-item-row">
            <div class="order-item-name">${item.name}</div>
            <div class="order-item-qty">${item.quantity} шт. × ${fmt(item.price)} ₸</div>
            <div class="order-item-price">${fmt(item.total)} ₸</div>
          </div>`).join("")
      : `<div class="state-msg" style="padding:20px">Позиции не найдены</div>`;

    // Итого
    document.getElementById("omTotal").textContent = `${fmt(o.total)} ₸`;

  } catch (e) {
    document.getElementById("omMeta").innerHTML = `<span class="order-meta-tag" style="color:#c0504d">Ошибка загрузки</span>`;
  }
}

function closeOrderModal() {
  const overlay = document.getElementById("orderModalOverlay");
  if (overlay) overlay.style.display = "none";
}

// ── ADMIN ───────────────────────────────────────────────────────────────────────
const ADMIN_TABS = ["products", "categories", "stores", "stocks", "masterdata"];
const ADMIN_ID_MAP = {
  products:   "adminProducts",
  categories: "adminCategories",
  stores:     "adminStores",
  stocks:     "adminStocks",
  masterdata: "adminMasterdata",
};

function switchAdminTab(tab) {
  ADMIN_TABS.forEach(t => {
    const el = document.getElementById(ADMIN_ID_MAP[t]);
    if (el) el.classList.toggle("active", t === tab);
  });
  document.querySelectorAll(".admin-tab").forEach(el => {
    el.classList.toggle("active", el.dataset.tab === tab);
  });
  if (tab === "stores") setTimeout(initAdminStoreMap, 150);
}

async function loadAdminData() {
  await Promise.all([loadAdminProducts(), loadAdminCategories(), loadAdminStores()]);
  buildAcData();
}

// ── КАРТА В ФОРМЕ МАГАЗИНА ─────────────────────────────────────────────────────
var adminStoreMap = null, adminStoreMarker = null;

function initAdminStoreMap() {
  var el = document.getElementById("adminStoreMap");
  if (!el || adminStoreMap || typeof L === "undefined") return;
  adminStoreMap = L.map("adminStoreMap").setView([43.238, 76.945], 12);
  L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {
    attribution: "© OpenStreetMap"
  }).addTo(adminStoreMap);
  adminStoreMap.on("click", function(e) {
    var lat = e.latlng.lat, lng = e.latlng.lng;
    document.getElementById("sLat").value = lat.toFixed(6);
    document.getElementById("sLng").value = lng.toFixed(6);
    fetch("https://nominatim.openstreetmap.org/reverse?lat=" + lat + "&lon=" + lng + "&format=json&accept-language=ru")
      .then(function(r){ return r.json(); })
      .then(function(data) {
        var a = data.address || {};
        var parts = [];
        if (a.road || a.pedestrian) parts.push((a.road || a.pedestrian) + (a.house_number ? " " + a.house_number : ""));
        else if (a.suburb) parts.push(a.suburb);
        if (a.city || a.town || a.village) parts.push(a.city || a.town || a.village);
        document.getElementById("sAddress").value = parts.length ? parts.join(", ") : (lat.toFixed(5) + ", " + lng.toFixed(5));
      })
      .catch(function() {
        document.getElementById("sAddress").value = lat.toFixed(5) + ", " + lng.toFixed(5);
      });
    if (adminStoreMarker) adminStoreMap.removeLayer(adminStoreMarker);
    adminStoreMarker = L.marker([lat, lng]).addTo(adminStoreMap);
  });
}

// ── AUTOCOMPLETE ────────────────────────────────────────────────────────────────
const acRegistry = {};

function buildAcData() {
  registerAc("pCatName",      "pCatId",      "acCategories",    adminCategoriesList.map(c => ({ id: c.id, label: c.name })));
  registerAc("stProductName", "stProductId", "acStockProducts", adminProductsList.map(p =>   ({ id: p.id, label: p.name, sub: fmt(p.price) + " ₸" })));
  registerAc("stStoreName",   "stStoreId",   "acStockStores",   adminStoresList.map(s =>    ({ id: s.id, label: s.name, sub: s.address })));
}

function registerAc(inputId, hiddenId, dropId, items) {
  acRegistry[inputId] = { hiddenId, dropId, items };
  renderAcItems(dropId, items, inputId, hiddenId);
}

function renderAcItems(dropId, items, inputId, hiddenId) {
  const drop = document.getElementById(dropId);
  if (!drop) return;

  if (!items.length) {
    drop.innerHTML = `<div class="ac-item" style="color:var(--text-light);cursor:default">Ничего не найдено</div>`;
    return;
  }

  drop.innerHTML = items.map(item => `
    <div class="ac-item"
      onmousedown="acPick('${inputId}','${hiddenId}','${dropId}',${item.id},'${item.label.replace(/'/g,"\\'")}')">
      ${item.label}
      ${item.sub ? `<small>${item.sub}</small>` : ""}
    </div>`).join("");
}

function acFilter(inputId, hiddenId, dropId) {
  const val = document.getElementById(inputId).value.toLowerCase();
  document.getElementById(hiddenId).value = "";
  const reg = acRegistry[inputId];
  if (!reg) return;
  const filtered = reg.items.filter(i => i.label.toLowerCase().includes(val));
  renderAcItems(dropId, filtered, inputId, hiddenId);
  acOpen(dropId);
}

function acPick(inputId, hiddenId, dropId, id, label) {
  document.getElementById(inputId).value = label;
  document.getElementById(hiddenId).value = id;
  acClose(dropId);
}

function acOpen(dropId)  { const d = document.getElementById(dropId); if (d) d.classList.add("open"); }
function acClose(dropId) { const d = document.getElementById(dropId); if (d) d.classList.remove("open"); }

// ── MODAL ───────────────────────────────────────────────────────────────────────
let modalTarget = null;

function openModal(type) {
  modalTarget = type;
  document.getElementById("modalTitle").textContent = type === "products" ? "Выберите товар" : "Выберите магазин";
  document.getElementById("modalSearch").value = "";
  document.getElementById("modalOverlay").style.display = "flex";
  filterModal();
}

function closeModal() {
  document.getElementById("modalOverlay").style.display = "none";
}

function filterModal() {
  const q = document.getElementById("modalSearch").value.toLowerCase();
  const items = modalTarget === "products" ? adminProductsList : adminStoresList;
  const filtered = items.filter(i => (i.name || "").toLowerCase().includes(q));
  const list = document.getElementById("modalList");
  if (!filtered.length) { list.innerHTML = '<div class="modal-empty">Ничего не найдено</div>'; return; }
  list.innerHTML = filtered.map(item => `
    <div class="modal-item" onclick="selectModal(${item.id}, ${JSON.stringify(item.name)})">
      <div>
        <strong>${item.name}</strong><br>
        <small>${modalTarget === "products" ? fmt(item.price) + " ₸" : (item.address || "")}</small>
      </div>
      <span class="modal-pick">Выбрать →</span>
    </div>`).join("");
}

function selectModal(id, name) {
  if (modalTarget === "products") {
    document.getElementById("stProductName").value = name;
    document.getElementById("stProductId").value = id;
  } else {
    document.getElementById("stStoreName").value = name;
    document.getElementById("stStoreId").value = id;
  }
  closeModal();
}

// ── CATEGORIES ──────────────────────────────────────────────────────────────────
async function loadAdminCategories() {
  try {
    adminCategoriesList = await api("/categories/");
    document.getElementById("categoriesTableBody").innerHTML = adminCategoriesList.map(c => `
      <tr>
        <td>${c.id}</td><td>${c.name}</td>
        <td><button class="del-btn" onclick="deleteCategory(${c.id})">Удалить</button></td>
      </tr>`).join("");
  } catch (e) { adminCategoriesList = []; }
}

async function createCategory() {
  const name = document.getElementById("catName").value.trim();
  const msgEl = document.getElementById("categoryFormMsg");
  if (!name) { msgEl.className = "msg-error"; msgEl.textContent = "Введите название"; return; }
  try {
    const token = getToken();
    const res = await fetch(`${BASE}/categories/?name=${encodeURIComponent(name)}`, {
      method: "POST", headers: { ...(token ? { Authorization: `Bearer ${token}` } : {}) }
    });
    if (!res.ok) { const e2 = await res.json().catch(() => {}); throw new Error(e2?.detail || "Ошибка"); }
    msgEl.className = "msg-ok"; msgEl.textContent = "Категория добавлена!";
    document.getElementById("catName").value = "";
    await loadAdminCategories(); buildAcData();
  } catch (e) { msgEl.className = "msg-error"; msgEl.textContent = e.message; }
}

async function deleteCategory(id) {
  if (!confirm("Удалить категорию?")) return;
  try { await api(`/categories/${id}`, { method: "DELETE" }); await loadAdminCategories(); buildAcData(); } catch (e) {}
}

// ── PRODUCTS CRUD ───────────────────────────────────────────────────────────────
async function loadAdminProducts() {
  try {
    adminProductsList = await api("/products/filter");
    document.getElementById("productsTableBody").innerHTML = adminProductsList.map(p => `
      <tr>
        <td>${p.id}</td>
        <td>
          ${p.image_url
            ? `<img src="${BASE}${p.image_url}" class="product-thumb" onerror="this.style.display='none'" />`
            : `<div class="product-thumb-placeholder">${getEmoji(p.category_name)}</div>`}
        </td>
        <td>${p.name}</td>
        <td>${fmt(p.price)} ₸</td>
        <td>${p.category_name || "—"}</td>
        <td>
          <label class="img-admin-btn" style="cursor:pointer">
            📷 Фото
            <input type="file" accept="image/*" style="display:none"
              onchange="uploadProductImageAdmin(${p.id}, event)" />
          </label>
        </td>
        <td><button class="del-btn" onclick="deleteProduct(${p.id})">Удалить</button></td>
      </tr>`).join("");
  } catch (e) { adminProductsList = []; }
}

async function uploadProductImageAdmin(productId, e) {
  const file = e.target.files && e.target.files[0];
  if (!file) return;
  const formData = new FormData();
  formData.append("file", file);
  const token = getToken();
  try {
    const res = await fetch(`${BASE}/products/${productId}/image`, {
      method: "POST",
      headers: token ? { Authorization: `Bearer ${token}` } : {},
      body: formData,
    });
    if (res.ok) {
      await loadAdminProducts();
      buildAcData();
      loadProducts();
    } else { alert("Ошибка загрузки фото"); }
  } catch { alert("Ошибка загрузки фото"); }
}

async function createProduct() {
  const name  = document.getElementById("pName").value.trim();
  const price = document.getElementById("pPrice").value;
  const desc  = document.getElementById("pDesc").value.trim();
  const catId = document.getElementById("pCatId").value;
  const msgEl = document.getElementById("productFormMsg");
  if (!name || !price) { msgEl.className = "msg-error"; msgEl.textContent = "Заполните название и цену"; return; }
  try {
    const params = new URLSearchParams();
    params.append("name", name);
    params.append("price", price);
    params.append("description", desc);
    if (catId) params.append("category_id", catId);
    const token = getToken();
    const res = await fetch(`${BASE}/products/?${params}`, {
      method: "POST",
      headers: { ...(token ? { Authorization: `Bearer ${token}` } : {}) }
    });
    if (!res.ok) {
      const err = await res.json().catch(() => ({}));
      throw new Error(err.detail || "Ошибка при добавлении товара");
    }
    msgEl.className = "msg-ok"; msgEl.textContent = "Товар добавлен!";
    ["pName", "pPrice", "pDesc", "pCatName"].forEach(id => document.getElementById(id).value = "");
    document.getElementById("pCatId").value = "";
    await loadAdminProducts(); buildAcData();
  } catch (e) { msgEl.className = "msg-error"; msgEl.textContent = e.message; }
}

async function deleteProduct(id) {
  if (!confirm("Удалить товар?")) return;
  try { await api(`/products/${id}`, { method: "DELETE" }); await loadAdminProducts(); buildAcData(); } catch (e) {}
}

// ── STORES CRUD ─────────────────────────────────────────────────────────────────
async function loadAdminStores() {
  try {
    adminStoresList = await api("/admin/stores/");
    document.getElementById("storesTableBody").innerHTML = adminStoresList.map(s => `
      <tr>
        <td>${s.id}</td><td>${s.name}</td><td>${s.address}</td>
        <td><button class="del-btn" onclick="deleteStore(${s.id})">Удалить</button></td>
      </tr>`).join("");
  } catch (e) { adminStoresList = []; }
}

async function createStore() {
  const name = document.getElementById("sName").value.trim();
  const fullAddress = document.getElementById("sAddress").value.trim();
  const msgEl = document.getElementById("storeFormMsg");
  if (!name || !fullAddress) { msgEl.className = "msg-error"; msgEl.textContent = "Заполните все поля"; return; }
  // Обрезаем длинный адрес Nominatim до первых 2 частей
  const parts = fullAddress.split(",").map(function(p){ return p.trim(); });
  const address = parts.slice(0, 2).join(", ");
  const lat = parseFloat(document.getElementById("sLat") && document.getElementById("sLat").value) || null;
  const lng = parseFloat(document.getElementById("sLng") && document.getElementById("sLng").value) || null;
  try {
    const token = getToken();
    const params = new URLSearchParams({ name, address });
    if (lat) params.append("lat", lat);
    if (lng) params.append("lng", lng);
    const res = await fetch(`${BASE}/admin/stores/?${params}`, {
      method: "POST", headers: { ...(token ? { Authorization: `Bearer ${token}` } : {}) }
    });
    if (!res.ok) { const e2 = await res.json().catch(() => {}); throw new Error(e2?.detail || "Ошибка"); }
    msgEl.className = "msg-ok"; msgEl.textContent = "Магазин добавлен!";
    document.getElementById("sName").value = "";
    document.getElementById("sAddress").value = "";
    if (document.getElementById("sLat")) document.getElementById("sLat").value = "";
    if (document.getElementById("sLng")) document.getElementById("sLng").value = "";
    if (adminStoreMarker && adminStoreMap) { adminStoreMap.removeLayer(adminStoreMarker); adminStoreMarker = null; }
    await loadAdminStores(); buildAcData();
  } catch (e) { msgEl.className = "msg-error"; msgEl.textContent = e.message; }
}

async function deleteStore(id) {
  if (!confirm("Удалить магазин?")) return;
  try { await api(`/admin/stores/${id}`, { method: "DELETE" }); await loadAdminStores(); buildAcData(); } catch (e) {}
}

// ── STOCKS ──────────────────────────────────────────────────────────────────────
async function setStock() {
  const productId = document.getElementById("stProductId").value;
  const storeId   = document.getElementById("stStoreId").value;
  const qty       = document.getElementById("stQty").value;
  const msgEl     = document.getElementById("stockFormMsg");
  if (!productId) { msgEl.className = "msg-error"; msgEl.textContent = "Выберите товар из списка"; return; }
  if (!storeId)   { msgEl.className = "msg-error"; msgEl.textContent = "Выберите магазин из списка"; return; }
  if (!qty)       { msgEl.className = "msg-error"; msgEl.textContent = "Введите количество"; return; }
  try {
    const token = getToken();
    const res = await fetch(`${BASE}/stocks/?product_id=${productId}&store_id=${storeId}&quantity=${qty}`, {
      method: "POST", headers: { ...(token ? { Authorization: `Bearer ${token}` } : {}) }
    });
    if (!res.ok) { const e3 = await res.json().catch(() => {}); throw new Error(e3?.detail || "Ошибка"); }
    msgEl.className = "msg-ok"; msgEl.textContent = "Остаток сохранён!";
    ["stProductName", "stStoreName", "stQty"].forEach(id => document.getElementById(id).value = "");
    document.getElementById("stProductId").value = "";
    document.getElementById("stStoreId").value = "";
  } catch (e) { msgEl.className = "msg-error"; msgEl.textContent = e.message; }
}

// ── MASTER DATA ─────────────────────────────────────────────────────────────────
const MD_IDS = {
  products: { progress: "progressProducts", result: "resultProducts" },
  stocks:   { progress: "progressStocks",   result: "resultStocks"   },
};

function mdExport(type) {
  const token = getToken();
  fetch(`${BASE}/masterdata/export/${type}`, {
    headers: token ? { Authorization: `Bearer ${token}` } : {}
  })
  .then(res => {
    if (!res.ok) throw new Error("Ошибка " + res.status);
    return res.blob();
  })
  .then(blob => {
    const a = document.createElement("a");
    a.href = URL.createObjectURL(blob);
    a.download = type + ".xlsx";
    document.body.appendChild(a);
    a.click();
    setTimeout(() => { document.body.removeChild(a); URL.revokeObjectURL(a.href); }, 100);
  })
  .catch(err => alert("Ошибка выгрузки: " + err.message));
}

function mdTemplate(type) {
  const token = getToken();
  fetch(`${BASE}/masterdata/export/template/${type}`, {
    headers: token ? { Authorization: `Bearer ${token}` } : {}
  })
  .then(res => {
    if (!res.ok) throw new Error("Ошибка " + res.status);
    return res.blob();
  })
  .then(blob => {
    const a = document.createElement("a");
    a.href = URL.createObjectURL(blob);
    a.download = "template_" + type + ".xlsx";
    document.body.appendChild(a);
    a.click();
    setTimeout(() => { document.body.removeChild(a); URL.revokeObjectURL(a.href); }, 100);
  })
  .catch(err => alert("Ошибка скачивания: " + err.message));
}

function mdDrop(e, type) {
  e.preventDefault();
  const file = e.dataTransfer && e.dataTransfer.files && e.dataTransfer.files[0];
  if (file) mdUpload(file, type);
}

function mdImport(e, type) {
  const file = e.target.files && e.target.files[0];
  e.target.value = "";
  if (file) mdUpload(file, type);
}

async function mdUpload(file, type) {
  const ids = MD_IDS[type];
  if (!ids) return;

  const progressEl = document.getElementById(ids.progress);
  const resultEl   = document.getElementById(ids.result);

  progressEl.style.display = "flex";
  resultEl.style.display   = "none";

  const formData = new FormData();
  formData.append("file", file);

  const token = getToken();
  try {
    const res = await fetch(`${BASE}/masterdata/import/${type}`, {
      method: "POST",
      headers: token ? { Authorization: `Bearer ${token}` } : {},
      body: formData,
    });

    progressEl.style.display = "none";

    let data;
    try { data = await res.json(); } catch { data = { detail: "Неверный ответ сервера" }; }

    if (res.ok) {
      resultEl.className   = "import-result ok";
      resultEl.style.display = "block";
      let html = "✅ " + (data.message || "Готово");
      if (data.errors && data.errors.length) {
        const shown = data.errors.slice(0, 10);
        html += "<ul>" + shown.map(function(e) { return "<li>" + e + "</li>"; }).join("") + "</ul>";
        if (data.errors.length > 10) html += "<p>...и ещё " + (data.errors.length - 10) + " ошибок</p>";
      }
      resultEl.innerHTML = html;
      if (type === "products") { await loadAdminProducts(); buildAcData(); }
    } else {
      resultEl.className   = "import-result err";
      resultEl.style.display = "block";
      resultEl.textContent = "❌ " + (data.detail || "Ошибка загрузки");
    }
  } catch (err) {
    progressEl.style.display = "none";
    resultEl.className   = "import-result err";
    resultEl.style.display = "block";
    resultEl.textContent = "❌ " + err.message;
  }
}

// ── INIT ────────────────────────────────────────────────────────────────────────
document.addEventListener("keydown", function(e) {
  var modal = document.getElementById("authModal");
  if (e.key === "Enter" && modal && modal.style.display !== "none") handleAuth();
  if (e.key === "Escape") { closeOrderModal(); closeAuthModal(); }
});

const savedToken = localStorage.getItem("token");
const savedUser  = localStorage.getItem("user");
if (savedToken && savedUser) {
  try {
    currentUser = JSON.parse(savedUser);
    // Обновляем кнопки для авторизованного пользователя
    var ub = document.getElementById("userInfoBlock");
    var bl = document.getElementById("btnLogin");
    var bo = document.getElementById("btnOrders");
    var ba = document.getElementById("btnAdmin");
    if (ub) ub.style.display = "flex";
    if (bl) bl.style.display = "none";
    if (bo) bo.style.display = "inline-flex";
    var ue = document.getElementById("userEmail");
    if (ue) ue.textContent = currentUser.email;
    if (currentUser.role === "admin" && ba) ba.style.display = "inline-flex";
  } catch { localStorage.clear(); }
}
// Всегда начинаем с лендинга
showLanding();