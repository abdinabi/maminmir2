import React, { useState } from "react";

export default function AdminProducts() {
  const [name, setName] = useState("");
  const [price, setPrice] = useState("");

  const createProduct = () => {
    fetch("http://localhost:8000/products", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ name, price })
    });
  };

  return (
    <div>
      <h2>Admin Products</h2>
      <input placeholder="name" onChange={e => setName(e.target.value)} />
      <input placeholder="price" onChange={e => setPrice(e.target.value)} />
      <button onClick={createProduct}>Create</button>
    </div>
  );
}