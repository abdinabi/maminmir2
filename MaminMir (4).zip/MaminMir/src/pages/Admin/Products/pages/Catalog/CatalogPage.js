import React, { useState, useEffect } from "react";

const CATEGORY_EMOJI = {
  default: "🧸",
  игрушки: "🧸",
  одежда: "👗",
  питание: "🍼",
  уход: "🧴",
  коляски: "🛒",
  мебель: "🪑",
};

function getEmoji(categoryName) {
  if (!categoryName) return CATEGORY_EMOJI.default;
  const key = categoryName.toLowerCase();
  for (const [k, v] of Object.entries(CATEGORY_EMOJI)) {
    if (key.includes(k)) return v;
  }
  return CATEGORY_EMOJI.default;
}

// Mock data — используется когда бэкенд недоступен
const MOCK_PRODUCTS = [
  { id: 1, name: "Мягкий мишка Тедди", description: "Гипоаллергенный, от 0+", price: 1200, category_id: 1, category_name: "Игрушки" },
  { id: 2, name: "Боди с принтом", description: "Хлопок 100%, размер 62–86", price: 850, category_id: 2, category_name: "Одежда" },
  { id: 3, name: "Смесь Nutrilon 1", description: "Для детей с рождения", price: 2300, category_id: 3, category_name: "Питание" },
  { id: 4, name: "Крем под подгузник", description: "Без парабенов и красителей", price: 420, category_id: 4, category_name: "Уход" },
  { id: 5, name: "Развивающий коврик", description: "С дугами и зеркалом, от 0+", price: 3100, category_id: 1, category_name: "Игрушки" },
  { id: 6, name: "Комбинезон флисовый", description: "Тёплый, антипилинг", price: 1600, category_id: 2, category_name: "Одежда" },
  { id: 7, name: "Пюре яблоко-груша", description: "Без сахара, 80г", price: 95, category_id: 3, category_name: "Питание" },
  { id: 8, name: "Шампунь детский", description: "Без слёз, 200мл", price: 310, category_id: 4, category_name: "Уход" },
];

export default function CatalogPage({ onAddToCart, cartItems }) {
  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [minPrice, setMinPrice] = useState("");
  const [maxPrice, setMaxPrice] = useState("");
  const [useMock, setUseMock] = useState(false);

  const fetchProducts = async (min, max) => {
    setLoading(true);
    try {
      const params = new URLSearchParams();
      if (min) params.append("min_price", min);
      if (max) params.append("max_price", max);
      const res = await fetch(`http://localhost:8000/products/filter?${params}`);
      if (!res.ok) throw new Error();
      const data = await res.json();
      if (data.length === 0 && !min && !max) {
        // Пустой ответ от бэкенда — используем mock
        setProducts(MOCK_PRODUCTS);
        setUseMock(true);
      } else {
        setProducts(data);
        setUseMock(false);
      }
    } catch {
      setProducts(
        MOCK_PRODUCTS.filter((p) => {
          if (min && p.price < Number(min)) return false;
          if (max && p.price > Number(max)) return false;
          return true;
        })
      );
      setUseMock(true);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { fetchProducts("", ""); }, []);

  const handleFilter = () => fetchProducts(minPrice, maxPrice);
  const handleReset = () => {
    setMinPrice("");
    setMaxPrice("");
    fetchProducts("", "");
  };

  const isInCart = (id) => cartItems.some((i) => i.product.id === id);

  const cartCount = (id) => {
    const item = cartItems.find((i) => i.product.id === id);
    return item ? item.quantity : 0;
  };

  return (
    <div>
      <div className="catalog-hero">
        <h1>
          Всё лучшее —<br />
          <span>маленьким и любимым</span>
        </h1>
        <p>Товары для малышей с заботой о каждой семье</p>
      </div>

      {useMock && (
        <div style={{
          background: "#fff8e6",
          border: "1.5px solid #f0d080",
          borderRadius: 10,
          padding: "10px 18px",
          fontSize: 13,
          color: "#a07020",
          marginBottom: 24,
          display: "flex",
          gap: 8,
          alignItems: "center"
        }}>
          ⚠️ Бэкенд не подключён — показаны демо-данные. Запустите FastAPI на <code>localhost:8000</code>.
        </div>
      )}

      <div className="filters">
        <span className="filter-label">Цена:</span>
        <input
          className="filter-input"
          placeholder="от ₸"
          type="number"
          value={minPrice}
          onChange={(e) => setMinPrice(e.target.value)}
          onKeyDown={(e) => e.key === "Enter" && handleFilter()}
        />
        <input
          className="filter-input"
          placeholder="до ₸"
          type="number"
          value={maxPrice}
          onChange={(e) => setMaxPrice(e.target.value)}
          onKeyDown={(e) => e.key === "Enter" && handleFilter()}
        />
        <button className="filter-btn" onClick={handleFilter}>Найти</button>
        {(minPrice || maxPrice) && (
          <button className="filter-reset" onClick={handleReset}>Сбросить</button>
        )}
      </div>

      {loading ? (
        <div className="state-msg">
          <span className="emoji">🌸</span>
          Загружаем товары…
        </div>
      ) : products.length === 0 ? (
        <div className="state-msg">
          <span className="emoji">🔍</span>
          Ничего не найдено. Попробуйте изменить фильтры.
        </div>
      ) : (
        <div className="products-grid">
          {products.map((product, idx) => (
            <div
              className="product-card"
              key={product.id}
              style={{ animationDelay: `${idx * 0.06}s` }}
            >
              <div className="product-img">
                {getEmoji(product.category_name)}
              </div>
              <div className="product-body">
                {product.category_name && (
                  <div className="product-category">{product.category_name}</div>
                )}
                <div className="product-name">{product.name}</div>
                {product.description && (
                  <div className="product-desc">{product.description}</div>
                )}
                <div className="product-footer">
                  <div className="product-price">
                    {product.price.toLocaleString("ru-RU")}
                    <span>₸</span>
                  </div>
                  <button
                    className={`add-btn ${isInCart(product.id) ? "in-cart" : ""}`}
                    onClick={() => onAddToCart(product)}
                    title={isInCart(product.id) ? `В корзине: ${cartCount(product.id)}` : "Добавить в корзину"}
                  >
                    {isInCart(product.id) ? "✓" : "+"}
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}