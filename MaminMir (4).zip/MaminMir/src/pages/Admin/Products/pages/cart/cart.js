import React, { useState } from "react";

export default function CartPage({ cart, onRemove, onUpdateQuantity, onBackToCatalog }) {
  const [ordered, setOrdered] = useState(false);
  const [loading, setLoading] = useState(false);

  const total = cart.reduce((sum, i) => sum + i.product.price * i.quantity, 0);
  const itemCount = cart.reduce((sum, i) => sum + i.quantity, 0);

  const handleOrder = async () => {
    setLoading(true);
    try {
      // Добавляем товары в корзину через API (user_id = 1 для демо)
      for (const item of cart) {
        await fetch(
          `http://localhost:8000/cart/add?user_id=1&product_id=${item.product.id}&quantity=${item.quantity}`,
          { method: "POST" }
        );
      }
      // Создаём заказ
      await fetch("http://localhost:8000/orders/?user_id=1", { method: "POST" });
    } catch {
      // Если бэкенд недоступен — всё равно показываем успех (демо-режим)
    } finally {
      setLoading(false);
      setOrdered(true);
    }
  };

  if (ordered) {
    return (
      <div className="order-success">
        <div className="big-emoji">🎀</div>
        <h2>Заказ оформлен!</h2>
        <p>Спасибо за покупку. Мы свяжемся с вами в ближайшее время.</p>
        <button className="checkout-btn" style={{ maxWidth: 260, margin: "0 auto" }} onClick={onBackToCatalog}>
          Вернуться в каталог
        </button>
      </div>
    );
  }

  if (cart.length === 0) {
    return (
      <div className="cart-page">
        <button className="back-btn" onClick={onBackToCatalog}>← Назад в каталог</button>
        <div className="state-msg">
          <span className="emoji">🛒</span>
          Корзина пуста. Добавьте товары из каталога!
        </div>
      </div>
    );
  }

  return (
    <div className="cart-page">
      <button className="back-btn" onClick={onBackToCatalog}>← Назад в каталог</button>
      <h1>Корзина</h1>

      <div className="cart-layout">
        <div className="cart-items">
          {cart.map((item) => (
            <div className="cart-item" key={item.product.id}>
              <div className="cart-item-icon">🧸</div>
              <div className="cart-item-info">
                <h3>{item.product.name}</h3>
                <p>{item.product.price.toLocaleString("ru-RU")} ₸ за шт.</p>
              </div>
              <div className="qty-control">
                <button
                  className="qty-btn"
                  onClick={() => onUpdateQuantity(item.product.id, item.quantity - 1)}
                >−</button>
                <span className="qty-num">{item.quantity}</span>
                <button
                  className="qty-btn"
                  onClick={() => onUpdateQuantity(item.product.id, item.quantity + 1)}
                >+</button>
              </div>
              <div className="cart-item-price">
                {(item.product.price * item.quantity).toLocaleString("ru-RU")} ₸
              </div>
              <button className="remove-btn" onClick={() => onRemove(item.product.id)} title="Удалить">✕</button>
            </div>
          ))}
        </div>

        <div className="cart-summary">
          <h2>Итого</h2>
          <div className="summary-line">
            <span>Товаров</span>
            <span>{itemCount} шт.</span>
          </div>
          <div className="summary-line">
            <span>Позиций</span>
            <span>{cart.length}</span>
          </div>
          <div className="summary-total">
            <span>К оплате</span>
            <span>{total.toLocaleString("ru-RU")} ₸</span>
          </div>
          <button
            className="checkout-btn"
            onClick={handleOrder}
            disabled={loading}
          >
            {loading ? "Оформляем…" : "Оформить заказ"}
          </button>
        </div>
      </div>
    </div>
  );
}