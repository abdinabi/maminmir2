import React, { createContext, useContext, useState, useEffect } from "react";
import { authAPI } from "./api";

const AuthContext = createContext(null);

export function AuthProvider({ children }) {
  const [user, setUser] = useState(null);       // { email, role, id }
  const [loading, setLoading] = useState(true);

  // Восстанавливаем сессию из localStorage при загрузке
  useEffect(() => {
    const token = localStorage.getItem("token");
    const savedUser = localStorage.getItem("user");
    if (token && savedUser) {
      try {
        setUser(JSON.parse(savedUser));
      } catch {
        localStorage.removeItem("user");
        localStorage.removeItem("token");
      }
    }
    setLoading(false);
  }, []);

  const login = async (email, password) => {
    const data = await authAPI.login(email, password);
    if (data.error) throw new Error(data.error);

    const token = data.access_token;
    localStorage.setItem("token", token);

    // Декодируем payload из JWT (без верификации — только для UI)
    const payload = JSON.parse(atob(token.split(".")[1]));
    const userData = { email: payload.sub, role: payload.role, id: payload.id || 1 };
    localStorage.setItem("user", JSON.stringify(userData));
    setUser(userData);
    return userData;
  };

  const register = async (email, password) => {
    await authAPI.register(email, password);
    // После регистрации сразу входим
    return login(email, password);
  };

  const logout = () => {
    localStorage.removeItem("token");
    localStorage.removeItem("user");
    setUser(null);
  };

  return (
    <AuthContext.Provider value={{ user, loading, login, register, logout }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  return useContext(AuthContext);
}