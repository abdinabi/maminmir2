const BASE_URL = "http://localhost:8000";

function getToken() {
  return localStorage.getItem("token");
}

async function request(path, options = {}) {
  const token = getToken();
  const headers = {
    "Content-Type": "application/json",
    ...(token ? { Authorization: `Bearer ${token}` } : {}),
    ...options.headers,
  };

  const res = await fetch(`${BASE_URL}${path}`, { ...options, headers });

  if (res.status === 401) {
    localStorage.removeItem("token");
    window.location.reload();
    return;
  }

  if (!res.ok) {
    const err = await res.json().catch(() => ({}));
    throw new Error(err.detail || "Ошибка запроса");
  }

  return res.json();
}

// AUTH
export const authAPI = {
  register: (email, password) =>
    request(`/auth/register?email=${encodeURIComponent(email)}&password=${encodeURIComponent(password)}`, {
      method: "POST",
    }),

  login: (email, password) =>
    request(`/auth/login?email=${encodeURIComponent(email)}&password=${encodeURIComponent(password)}`, {
      method: "POST",
    }),
};

// PRODUCTS
export const productsAPI = {
  filter: (minPrice, maxPrice) => {
    const params = new URLSearchParams();
    if (minPrice) params.append("min_price", minPrice);
    if (maxPrice) params.append("max_price", maxPrice);
    return request(`/products/filter?${params}`);
  },
};

// CART
export const cartAPI = {
  add: (userId, productId, quantity) =>
    request(`/cart/add?user_id=${userId}&product_id=${productId}&quantity=${quantity}`, {
      method: "POST",
    }),
};

// ORDERS
export const ordersAPI = {
  create: (userId) =>
    request(`/orders/?user_id=${userId}`, { method: "POST" }),
};

// STORES
export const storesAPI = {
  getAll: () => request("/admin/stores/"),
};