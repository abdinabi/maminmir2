from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles
import os
from backend.database import engine, Base

from backend.routers import products, stores, stocks, cart, categories, masterdata
from backend.core import auth
from backend.models import orders

app = FastAPI()

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

Base.metadata.create_all(bind=engine)

app.include_router(auth.router,        prefix="/auth",         tags=["Auth"])
app.include_router(products.router,    prefix="/products",     tags=["Products"])
app.include_router(categories.router,  prefix="/categories",   tags=["Categories"])
app.include_router(stores.router,      prefix="/admin/stores", tags=["Stores"])
app.include_router(cart.router,        prefix="/cart",         tags=["Cart"])
app.include_router(stocks.router,      prefix="/stocks",       tags=["Stocks"])
app.include_router(orders.router,      prefix="/orders",       tags=["Orders"])
app.include_router(masterdata.router,  prefix="/masterdata",   tags=["MasterData"])

# Раздача загруженных фото
os.makedirs("frontend/uploads", exist_ok=True)
app.mount("/uploads", StaticFiles(directory="frontend/uploads"), name="uploads")

# Раздача статики фронтенда
app.mount("/static", StaticFiles(directory="frontend"), name="static")

@app.get("/home")
def serve_frontend():
    return FileResponse("./frontend/index2.html")